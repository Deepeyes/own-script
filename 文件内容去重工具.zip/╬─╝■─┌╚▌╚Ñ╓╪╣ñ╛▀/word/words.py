# -*- coding:utf-8 -*-
#! python3
#
#
import sys


def main(file_dst):
	start=0
	end=0
	start_file = "%s"%(str(file_dst)) #old
	end_file = "%snew.txt"%(str(file_dst.split('.')[0])) #new
	# txtDir = "/home/Administrator/Desktop/１"
	lines_seen = set()
	outfile = open(end_file, "w",encoding='utf8')
	f = open(start_file, "r",encoding='utf8')
	for line in f:
		start+=1
		if line not in lines_seen:
			end+=1
			outfile.write(line)
			lines_seen.add(line)
	outfile.close()
	count=start-end
	print('Start with %s words'%start+'\n'+'End with %s words'%end+'\n'+'Success to clear %s words'%count)


if __name__=='__main__':
	print('''
*Made by  :tdcoming
*QQ Group :256998718
*For More :https://t.zsxq.com/Ai2rj6E
*MY Heart :https://t.zsxq.com/A2FQFMN




			  _______   _                         _               
			 |__   __| | |                       (_)              
			    | |  __| |  ___  ___   _ __ ___   _  _ __    __ _ 
			    | | / _` | / __|/ _ \ | '_ ` _ \ | || '_ \  / _` |
			    | || (_| || (__| (_) || | | | | || || | | || (_| |
			    |_| \__,_| \___|\___/ |_| |_| |_||_||_| |_| \__, |
			                                                 __/ |
			                                                |___/ 


		''')
	if len(sys.argv)!=2:
		print('Enter:python %s "1.txt"'%sys.argv[0])
		exit(-1)
	else:
		main(sys.argv[1])
		exit(0)
